//  Copyright 2011 Logic Diner. All rights reserved.


#import <UIKit/UIKit.h>
#import "TwitterAuthController.h"

@interface SecondViewController : UIViewController {
    
}

@end
