//  Copyright 2011 Logic Diner. All rights reserved.


#import <UIKit/UIKit.h>


@interface FirstViewController : UIViewController {

}

@end
