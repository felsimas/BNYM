#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface SettingsViewController : UIViewController {

}

@end
