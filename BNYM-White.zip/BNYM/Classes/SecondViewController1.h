//
//  SecondViewController1.h
//  globe
//
//  Created by isaac silva on 5/23/11.
//  Copyright 2011 NYU. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SecondViewController1 : UIViewController {
    
}

@end
